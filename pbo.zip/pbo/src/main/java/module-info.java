module com.mycompany.pbo {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens com.mycompany.pbo to javafx.fxml;
    exports com.mycompany.pbo;
}
