package com.mycompany.pbo;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class homecontroller {

    @FXML
    private Label button_absen;

    @FXML
    private Label button_grafik;

    @FXML
    private Label button_keluar;

    @FXML
    private Label button_laporan;

}
