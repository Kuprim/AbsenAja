package com.mycompany.pbo;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class grafikcontroller {

    @FXML
    private Label button_absen;

    @FXML
    private Label button_home;

    @FXML
    private Label button_keluar;

    @FXML
    private Label button_laporan;

}
