package com.mycompany.pbo;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class laporancontroller {
    
     @FXML
    private Button button_login;

    
   public void to_home() throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("home.fxml"));
        Stage window = (Stage)button_login.getScene().getWindow();
        window.setScene(new Scene(root));
        window.show();
        window.setMaximized(false);
        window.setMaximized(true);
        window.setResizable(false);
    }
}
