package com.mycompany.pbo;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;

public class absencontroller {

    @FXML
    private Button button_edit;

    @FXML
    private Label button_grafik;

    @FXML
    private Button button_hapus;

    @FXML
    private Label button_home;

    @FXML
    private ImageView button_keluar;

    @FXML
    private Label button_laporan;

    @FXML
    private Button button_tambah;

}
