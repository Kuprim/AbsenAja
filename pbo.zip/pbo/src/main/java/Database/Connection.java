/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Database;

import java.sql.*;
    
/**
 *
 * @author lenovo
 */
public class Connection {
     static final String JDBC_DRIVER = "com.mysql.jdbc.driver";
     static final String DB_URL = "jdbc:mysql://localhost:3306/ta_pbo";
     static final String DB_USER = "root";
     static final String DB_PASSWORD = "";
     
     public static Connection connect(){
         try {
             
             Connection connection = (Connection) DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             System.out.println("Database Connect");
             return connection;
         } catch (SQLException e) {
             System.err.println("Connection error : "+e.getMessage());
             return null;
         }
     }
}
